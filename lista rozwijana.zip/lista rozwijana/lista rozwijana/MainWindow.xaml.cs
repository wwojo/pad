﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace lista_rozwijana
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public List<string> MojeOpcje { get; set; }

        public void Funkcja(object sender, RoutedEventArgs e)
        {
            if (listaaa.SelectedItem is ComboBoxItem element)
            {
                string wybrane = element.Content.ToString();

                switch (wybrane)
                {
                    case "sport":
                        MessageBox.Show("Lubisz sport");
                        break;
                    case "muzyka":
                        MessageBox.Show("Lubisz muzykę");
                        break;
                    case "podroze":
                        MessageBox.Show("Lubisz podróże");
                        break;
                    default:
                        MessageBox.Show("Nie wybrano żadnej odpowiedzi");
                        break;
                }
            }
            else
            {
                MessageBox.Show("Nie wybrano żadnej odpowiedzi");
            }
        }

    }
}
